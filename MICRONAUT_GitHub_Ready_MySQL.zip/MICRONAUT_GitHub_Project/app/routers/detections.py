from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app import schemas, services

router = APIRouter(prefix="/detections", tags=["AI detections"])

@router.post("/", response_model=schemas.DetectionRead, status_code=201)
def add_detection(payload: schemas.DetectionCreate, db: Session = Depends(get_db)):
    """Store a detection result produced by the vision model."""
    return services.create_detection(db, payload)

@router.get("/", response_model=list[schemas.DetectionRead])
def get_detections(
    pollutants_only: bool = False,
    limit: int = Query(default=100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    return services.list_detections(db, pollutants_only, limit)
