from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app import schemas, models, services

router = APIRouter(prefix="/devices", tags=["Devices"])

@router.put("/status", response_model=schemas.DeviceStatusRead)
def update_device_status(
    payload: schemas.DeviceStatusUpdate,
    db: Session = Depends(get_db),
):
    """Create or update the latest known device status."""
    return services.update_device(db, payload)

@router.get("/", response_model=list[schemas.DeviceStatusRead])
def list_devices(db: Session = Depends(get_db)):
    return db.query(models.DeviceStatus).order_by(
        models.DeviceStatus.device_id
    ).all()
