from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app import schemas, services

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])

@router.post("/", response_model=schemas.TelemetryRead, status_code=201)
def ingest_telemetry(payload: schemas.TelemetryCreate, db: Session = Depends(get_db)):
    """Receive a sensor telemetry record from the MICRONAUT device."""
    return services.create_telemetry(db, payload)

@router.get("/", response_model=list[schemas.TelemetryRead])
def read_telemetry(
    device_id: str | None = None,
    limit: int = Query(default=100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """List recent telemetry, optionally for one device."""
    return services.list_telemetry(db, device_id, limit)

@router.get("/recent", response_model=list[schemas.TelemetryRead])
def recent_telemetry(
    hours: int = Query(default=24, ge=1, le=720),
    db: Session = Depends(get_db),
):
    return services.get_recent_telemetry(db, hours)

@router.get("/{record_id}", response_model=schemas.TelemetryRead)
def telemetry_by_id(record_id: int, db: Session = Depends(get_db)):
    rows = services.list_telemetry(db, limit=1000)
    for row in rows:
        if row.id == record_id:
            return row
    raise HTTPException(status_code=404, detail="Telemetry record not found")
