from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app import schemas, services

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/summary", response_model=schemas.SummaryRead)
def dashboard_summary(db: Session = Depends(get_db)):
    """Return high-level counts for dashboard cards."""
    return services.get_summary(db)

@router.get("/telemetry", response_model=list[schemas.TelemetryRead])
def dashboard_telemetry(
    limit: int = 50,
    db: Session = Depends(get_db),
):
    return services.list_telemetry(db, limit=min(max(limit, 1), 500))
